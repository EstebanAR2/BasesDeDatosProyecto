// App.jsx
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import DashboardLayout from "./components/layout/DashboardLayout";
import ProveedorList from "./pages/proveedores/ProveedorList";
import ComponenteList from "./pages/componentes/ComponenteList";
import ContratoList from "./pages/contratos/ContratoList";
import OrdenCompraList from "./pages/ordenes/OrdenCompraList";
import FacturaList from "./pages/facturas/FacturaList";
import InventarioList from "./pages/inventario/InventarioList";
import SeguimientoEnvioList from "./pages/envios/SeguimientoEnvioList";
import SeguimientoLogisticoList from "./pages/logistica/SeguimientoLogisticoList";
import EventoProveedorList from "./pages/eventos/EventoProveedorList";

function App() {
  return (
    <Router>
      <DashboardLayout>
        <Routes>
          <Route path="/" element={<ProveedorList />} />
          <Route path="/componentes" element={<ComponenteList />} />
          <Route path="/contratos" element={<ContratoList />} />
          <Route path="/ordenes" element={<OrdenCompraList />} />
          <Route path="/facturas" element={<FacturaList />} />
          <Route path="/inventario" element={<InventarioList />} />
          <Route path="/envios" element={<SeguimientoEnvioList />} />
          <Route path="/logistica" element={<SeguimientoLogisticoList />} />
          <Route path="/eventos" element={<EventoProveedorList />} />
        </Routes>
      </DashboardLayout>
    </Router>
  );
}

export default App;
