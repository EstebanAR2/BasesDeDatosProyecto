// src/services/componenteService.js
import api from "./api";

// Get all componentes
export const getComponentes = () => api.get("/componentes");

// Get componente by ID
export const getComponenteById = (id) => api.get(`/componentes/${id}`);

// Create (save) a new componente
export const createComponente = (data) => api.post("/componentes", data);

// Update an existing componente
export const updateComponente = (id, data) => api.put(`/componentes/${id}`, data);

// Delete a componente
export const deleteComponente = (id) => api.delete(`/componentes/${id}`);
