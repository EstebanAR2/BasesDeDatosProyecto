// src/services/facturaService.js
import api from "./api";

// Get all facturas
export const getFacturas = () => api.get("/facturas");

// Get factura by ID
export const getFacturaById = (id) => api.get(`/facturas/${id}`);

// Get facturas by orden ID
export const getFacturasByOrden = (idOrden) => api.get(`/facturas/orden/${idOrden}`);

// Create (save) a new factura
export const createFactura = (data) => api.post("/facturas", data);

// Update an existing factura
export const updateFactura = (id, data) => api.put(`/facturas/${id}`, data);

// Delete a factura
export const deleteFactura = (id) => api.delete(`/facturas/${id}`);
