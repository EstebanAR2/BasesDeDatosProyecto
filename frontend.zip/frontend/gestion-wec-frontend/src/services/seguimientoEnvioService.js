// src/services/seguimientoEnvioService.js
import api from "./api";

// 🔹 Obtener todos los seguimientos
export const getSeguimientos = () => api.get("/seguimientos");

// 🔹 Obtener un seguimiento por ID
export const getSeguimientoById = (id) => api.get(`/seguimientos/${id}`);

// 🔹 Obtener seguimiento(s) por orden de compra
export const getSeguimientosByOrden = (idOrden) => api.get(`/seguimientos/orden/${idOrden}`);

// 🔹 Crear un nuevo seguimiento
export const createSeguimiento = (data) => api.post("/seguimientos", data);

// 🔹 Actualizar seguimiento existente
export const updateSeguimiento = (id, data) => api.put(`/seguimientos/${id}`, data);

// 🔹 Eliminar seguimiento
export const deleteSeguimiento = (id) => api.delete(`/seguimientos/${id}`);
