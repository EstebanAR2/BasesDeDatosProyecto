// src/services/seguimientoLogisticoService.js
import api from "./api";

// 🔹 Obtener todos los seguimientos
export const getSeguimientosLogisticos = () => api.get("/seguimiento-logistico");

// 🔹 Obtener seguimiento por ID
export const getSeguimientoLogisticoById = (id) => api.get(`/seguimiento-logistico/${id}`);

// 🔹 Obtener seguimientos por proveedor
export const getSeguimientosByProveedor = (idProveedor) =>
  api.get(`/seguimiento-logistico/proveedor/${idProveedor}`);

// 🔹 Obtener seguimientos por estado actual
export const getSeguimientosByEstado = (estado) =>
  api.get(`/seguimiento-logistico/estado/${estado}`);

// 🔹 Obtener seguimientos por orden de compra
export const getSeguimientosByOrden = (idCompra) =>
  api.get(`/seguimiento-logistico/orden/${idCompra}`);

// 🔹 Crear nuevo seguimiento
export const createSeguimientoLogistico = (data) =>
  api.post("/seguimiento-logistico", data);

// 🔹 Actualizar seguimiento
export const updateSeguimientoLogistico = (id, data) =>
  api.put(`/seguimiento-logistico/${id}`, data);

// 🔹 Eliminar seguimiento
export const deleteSeguimientoLogistico = (id) =>
  api.delete(`/seguimiento-logistico/${id}`);
