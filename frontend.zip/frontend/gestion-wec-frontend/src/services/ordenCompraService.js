// src/services/ordenCompraService.js
import api from "./api";

// Obtener todas las órdenes
export const getOrdenes = () => api.get("/ordenes");

// Obtener una orden por ID
export const getOrdenById = (id) => api.get(`/ordenes/${id}`);

// Obtener órdenes por proveedor
export const getOrdenesByProveedor = (idProveedor) => api.get(`/ordenes/proveedor/${idProveedor}`);

// Crear una nueva orden
export const createOrden = (data) => api.post("/ordenes", data);

// Actualizar una orden existente
export const updateOrden = (id, data) => api.put(`/ordenes/${id}`, data);

// Eliminar una orden
export const deleteOrden = (id) => api.delete(`/ordenes/${id}`);
