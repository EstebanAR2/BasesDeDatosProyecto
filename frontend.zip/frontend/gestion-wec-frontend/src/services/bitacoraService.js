// src/services/bitacoraService.js
import api from "./api";

// Get all bitácoras
export const getBitacoras = () => api.get("/bitacoras");

// Get bitácora by ID
export const getBitacoraById = (id) => api.get(`/bitacoras/${id}`);

// Get bitácoras by usuario
export const getBitacorasByUsuario = (usuario) => api.get(`/bitacoras/usuario/${usuario}`);

// Create (save) a new bitácora
export const createBitacora = (data) => api.post("/bitacoras", data);

// Update a bitácora by ID
export const updateBitacora = (id, data) => api.put(`/bitacoras/${id}`, data);

// Delete a bitácora
export const deleteBitacora = (id) => api.delete(`/bitacoras/${id}`);
