// src/services/eventoProveedorService.js
import api from "./api";

// Get all eventos
export const getEventos = () => api.get("/eventos-proveedor");

// Get eventos by proveedor ID
export const getEventosByProveedor = (idProveedor) => api.get(`/eventos-proveedor/proveedor/${idProveedor}`);

// Create (save) a new evento
export const createEvento = (data) => api.post("/eventos-proveedor", data);
