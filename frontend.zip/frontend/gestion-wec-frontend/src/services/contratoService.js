// src/services/contratoService.js
import api from "./api";

// Get all contratos
export const getContratos = () => api.get("/contratos");

// Get contrato by ID
export const getContratoById = (id) => api.get(`/contratos/${id}`);

// Create (save) a new contrato
export const createContrato = (data) => api.post("/contratos", data);

// Update an existing contrato
export const updateContrato = (id, data) => api.put(`/contratos/${id}`, data);

// Delete a contrato
export const deleteContrato = (id) => api.delete(`/contratos/${id}`);
