// src/services/inventarioService.js
import api from "./api";

// Obtener todos los inventarios
export const getInventarios = () => api.get("/inventarios");

// Obtener inventario por ID
export const getInventarioById = (id) => api.get(`/inventarios/${id}`);

// Obtener inventarios por proveedor
export const getInventariosByProveedor = (proveedorId) => api.get(`/inventarios/proveedor/${proveedorId}`);

// Crear un inventario
export const createInventario = (data) => api.post("/inventarios", data);

// Actualizar inventario
export const updateInventario = (id, data) => api.put(`/inventarios/${id}`, data);

// Eliminar inventario
export const deleteInventario = (id) => api.delete(`/inventarios/${id}`);
