import { Outlet, Link } from "react-router-dom";
import { Package, Users, FileText, ShoppingCart, Layers, ClipboardList, Truck, BarChart3 } from "lucide-react";

export default function DashboardLayout() {
  return (
    <div className="min-h-screen flex bg-gray-100">
      {/* Sidebar */}
      <aside className="w-64 bg-white shadow-md flex flex-col p-4">
        <h1 className="text-2xl font-bold text-blue-700 mb-8">Gestión Proveedores</h1>
        <nav className="space-y-3">
          <Link className="flex items-center gap-2 p-2 rounded-md hover:bg-blue-50" to="/dashboard">
            <BarChart3 className="w-5 h-5 text-blue-600" /> Dashboard
          </Link>
          <Link className="flex items-center gap-2 p-2 rounded-md hover:bg-blue-50" to="/proveedores">
            <Users className="w-5 h-5 text-blue-600" /> Proveedores
          </Link>
          <Link className="flex items-center gap-2 p-2 rounded-md hover:bg-blue-50" to="/contratos">
            <FileText className="w-5 h-5 text-blue-600" /> Contratos
          </Link>
          <Link className="flex items-center gap-2 p-2 rounded-md hover:bg-blue-50" to="/ordenes">
            <ShoppingCart className="w-5 h-5 text-blue-600" /> Órdenes
          </Link>
          <Link className="flex items-center gap-2 p-2 rounded-md hover:bg-blue-50" to="/facturas">
            <ClipboardList className="w-5 h-5 text-blue-600" /> Facturas
          </Link>
          <Link className="flex items-center gap-2 p-2 rounded-md hover:bg-blue-50" to="/inventario">
            <Layers className="w-5 h-5 text-blue-600" /> Inventario
          </Link>
          <Link className="flex items-center gap-2 p-2 rounded-md hover:bg-blue-50" to="/envios">
            <Truck className="w-5 h-5 text-blue-600" /> Envíos
          </Link>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 overflow-auto">
        <Outlet /> {/* Aquí se cargan las páginas */}
      </main>
    </div>
  );
}
